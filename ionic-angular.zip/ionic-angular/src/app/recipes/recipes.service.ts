import { Injectable } from '@angular/core';
import { Recipe } from './recipe.model';
import { Observable, of, from } from 'rxjs';
import { delay } from 'rxjs/internal/operators';

@Injectable({
  providedIn: 'root'
})
export class RecipesService {

  recipes: Recipe[] = [
    {
      id: 'r1',
      title: 'Schnitzel',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Breitenlesau_Krug_Br%C3%A4u_Schnitzel.JPG/800px-Breitenlesau_Krug_Br%C3%A4u_Schnitzel.JPG',
      ingredients: ['French fries', 'Pork', 'Salad']
    },
    {
      id: 'r2',
      title: 'Spaghetti',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/92/Spaghettoni.jpg',
      ingredients: ['Spaghetti', 'Pork', 'Tomatoes']
    },
    {
      id: 'r3',
      title: 'Choco',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/70/Chocolate_%28blue_background%29.jpg',
      ingredients: ['Milk', 'Choclate', 'Sugar cubes']
    },
  ];

  constructor() { }

  getRecipes(): Observable<Recipe[]>{
    return of(this.recipes).pipe(delay(2000));
  } 

  getRecipe(id):Observable<Recipe>{
    return of(this.recipes.filter((recipe)=>{return recipe.id == id})[0]).pipe(delay(2000));
  }
  
  deleteRecipe(id):Observable<any>{
    this.recipes = this.recipes.filter((recipe)=>{return recipe.id != id});
    return of(
      {
        "success":true
      }
    ).pipe(delay(3000));

  }

}
