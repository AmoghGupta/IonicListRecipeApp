import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RecipesService } from '../recipes.service';
import { Subscription } from 'rxjs';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.page.html',
  styleUrls: ['./recipe-details.page.scss'],
})
export class RecipeDetailsPage implements OnInit {

  recipeDetails = {};
  private recipeSubscription$:Subscription;
  

  constructor(
    private route: Router,
    private activedRoute: ActivatedRoute,
    private recipeData:RecipesService,
    public loadingController: LoadingController,
    public alertController: AlertController) { }

  ngOnInit() {
    this.loadRecipe();
  }
  async presentAlertConfirm() {
    const alert = await this.alertController.create({
      header: 'Confirm!!',
      message: '<strong>Are you sure you want to delete recipe?</strong>!!!',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        }, {
          text: 'Okay',
          handler: this.deleteHandler.bind(this)
        }
      ]
    });

    await alert.present();
  }

  async deleteHandler(){
    const loading = await this.loadingController.create({
      message: 'Please wait..Deleting recipes...',      
    });
    await loading.present();
    let recipedId = this.recipeDetails['id'];
    this.recipeData.deleteRecipe(recipedId).subscribe((data)=>{
      if(data['success']){
        loading.dismiss();
        this.route.navigate(['recipes']);
      }
    });
  }

  

  async loadRecipe(){
    const loading = await this.loadingController.create({
      message: 'Fetching your recipe details...',      
    });
    await loading.present();

    this.activedRoute.params.subscribe((param)=>{
      this.recipeSubscription$ = this.recipeData.getRecipe(param.recipeId).subscribe((data)=>{
        loading.dismiss();
        this.recipeDetails = data;
      });
    });
  }

  goBack(){
    this.route.navigate(['recipes']);
  }

  async deleteRecipe(){
    this.presentAlertConfirm();

  }

  ngOnDestroy(){
    this.recipeSubscription$.unsubscribe();
  }
}
