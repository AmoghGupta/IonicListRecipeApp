import { Component, OnInit, OnDestroy } from '@angular/core';
import { Recipe } from './recipe.model';
import { RecipesService } from './recipes.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.page.html',
  styleUrls: ['./recipes.page.scss'],
})
export class RecipesPage implements OnInit{

  recipes: Recipe[] =[];
  recipedSubscription$:Subscription;

  constructor(private recipesService:RecipesService, 
    private router:Router,
    private activedRoute: ActivatedRoute,
    public loadingController: LoadingController
    ) { }

  ngOnInit() {
    //this.loadData();
  }

  async loadData(){
    const loading = await this.loadingController.create({
      message: 'Loading Data',      
    });
    await loading.present();
    this.recipedSubscription$ =this.recipesService.getRecipes().subscribe((data)=>{
        loading.dismiss();
        this.recipes = data;
      });
  }

  ionViewWillEnter(){
    this.loadData();
  }

  showRecipeDetails(recipe){
    this.router.navigate(['recipes', recipe.id]);
  }

  ngOnDestroy(){
    this.recipedSubscription$.unsubscribe();
  }

}
